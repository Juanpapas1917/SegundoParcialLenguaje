
# Proyecto: Implementación de la Transformada de Fourier

Este proyecto implementa un lexer y parser para analizar expresiones relacionadas con la Transformada de Fourier utilizando una gramática definida con ANTLR. El objetivo del proyecto es procesar estas expresiones y ejecutar la lógica correspondiente en Python.

## Requisitos Previos

1. **Python 3.12.3**
2. **ANTLR 4.13.1**
3. Instalación de los paquetes especificados en `requirements.txt`.

## Estructura del Proyecto

- **FourierGrammar.g4**: Archivo de gramática ANTLR para la Transformada de Fourier.
- **FourierGrammarLexer.py**: Lexer generado por ANTLR.
- **FourierGrammarParser.py**: Parser generado por ANTLR.
- **main.py**: Script principal que ejecuta el procesamiento de las expresiones relacionadas con la Transformada de Fourier.

## Instrucciones de Uso

1. **Generar el Lexer y Parser con ANTLR**:
   Ejecuta el siguiente comando para generar los archivos necesarios a partir de la gramática:

   ```bash
   antlr4 -Dlanguage=Python3 FourierGrammar.g4
   ```

2. **Ejecutar el Programa**:
   Usa el siguiente comando para ejecutar el archivo `main.py`, que procesa las expresiones relacionadas con la Transformada de Fourier:

   ```bash
   python3 main.py
   ```

## Autor

Proyecto desarrollado por [Tu Nombre].

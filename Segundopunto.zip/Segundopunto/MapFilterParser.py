# Generated from MapFilter.g4 by ANTLR 4.13.0
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,7,46,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,6,
        1,0,4,0,16,8,0,11,0,12,0,17,1,0,1,0,1,1,1,1,1,2,1,2,3,2,26,8,2,1,
        3,1,3,1,3,1,3,1,3,1,3,1,3,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,5,1,5,1,
        6,1,6,1,6,0,0,7,0,2,4,6,8,10,12,0,0,40,0,15,1,0,0,0,2,21,1,0,0,0,
        4,25,1,0,0,0,6,27,1,0,0,0,8,34,1,0,0,0,10,41,1,0,0,0,12,43,1,0,0,
        0,14,16,3,2,1,0,15,14,1,0,0,0,16,17,1,0,0,0,17,15,1,0,0,0,17,18,
        1,0,0,0,18,19,1,0,0,0,19,20,5,0,0,1,20,1,1,0,0,0,21,22,3,4,2,0,22,
        3,1,0,0,0,23,26,3,6,3,0,24,26,3,8,4,0,25,23,1,0,0,0,25,24,1,0,0,
        0,26,5,1,0,0,0,27,28,5,1,0,0,28,29,5,2,0,0,29,30,3,10,5,0,30,31,
        5,3,0,0,31,32,3,12,6,0,32,33,5,4,0,0,33,7,1,0,0,0,34,35,5,5,0,0,
        35,36,5,2,0,0,36,37,3,10,5,0,37,38,5,3,0,0,38,39,3,12,6,0,39,40,
        5,4,0,0,40,9,1,0,0,0,41,42,5,6,0,0,42,11,1,0,0,0,43,44,5,6,0,0,44,
        13,1,0,0,0,2,17,25
    ]

class MapFilterParser ( Parser ):

    grammarFileName = "MapFilter.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'MAP'", "'('", "','", "')'", "'FILTER'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "ID", "WS" ]

    RULE_program = 0
    RULE_statement = 1
    RULE_expression = 2
    RULE_mapExpr = 3
    RULE_filterExpr = 4
    RULE_function_name = 5
    RULE_iterable_name = 6

    ruleNames =  [ "program", "statement", "expression", "mapExpr", "filterExpr", 
                   "function_name", "iterable_name" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    ID=6
    WS=7

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.0")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ProgramContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EOF(self):
            return self.getToken(MapFilterParser.EOF, 0)

        def statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MapFilterParser.StatementContext)
            else:
                return self.getTypedRuleContext(MapFilterParser.StatementContext,i)


        def getRuleIndex(self):
            return MapFilterParser.RULE_program

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterProgram" ):
                listener.enterProgram(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitProgram" ):
                listener.exitProgram(self)




    def program(self):

        localctx = MapFilterParser.ProgramContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_program)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 15 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 14
                self.statement()
                self.state = 17 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==1 or _la==5):
                    break

            self.state = 19
            self.match(MapFilterParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self):
            return self.getTypedRuleContext(MapFilterParser.ExpressionContext,0)


        def getRuleIndex(self):
            return MapFilterParser.RULE_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStatement" ):
                listener.enterStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStatement" ):
                listener.exitStatement(self)




    def statement(self):

        localctx = MapFilterParser.StatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_statement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 21
            self.expression()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def mapExpr(self):
            return self.getTypedRuleContext(MapFilterParser.MapExprContext,0)


        def filterExpr(self):
            return self.getTypedRuleContext(MapFilterParser.FilterExprContext,0)


        def getRuleIndex(self):
            return MapFilterParser.RULE_expression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpression" ):
                listener.enterExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpression" ):
                listener.exitExpression(self)




    def expression(self):

        localctx = MapFilterParser.ExpressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_expression)
        try:
            self.state = 25
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [1]:
                self.enterOuterAlt(localctx, 1)
                self.state = 23
                self.mapExpr()
                pass
            elif token in [5]:
                self.enterOuterAlt(localctx, 2)
                self.state = 24
                self.filterExpr()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MapExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def function_name(self):
            return self.getTypedRuleContext(MapFilterParser.Function_nameContext,0)


        def iterable_name(self):
            return self.getTypedRuleContext(MapFilterParser.Iterable_nameContext,0)


        def getRuleIndex(self):
            return MapFilterParser.RULE_mapExpr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMapExpr" ):
                listener.enterMapExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMapExpr" ):
                listener.exitMapExpr(self)




    def mapExpr(self):

        localctx = MapFilterParser.MapExprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_mapExpr)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 27
            self.match(MapFilterParser.T__0)
            self.state = 28
            self.match(MapFilterParser.T__1)
            self.state = 29
            self.function_name()
            self.state = 30
            self.match(MapFilterParser.T__2)
            self.state = 31
            self.iterable_name()
            self.state = 32
            self.match(MapFilterParser.T__3)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FilterExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def function_name(self):
            return self.getTypedRuleContext(MapFilterParser.Function_nameContext,0)


        def iterable_name(self):
            return self.getTypedRuleContext(MapFilterParser.Iterable_nameContext,0)


        def getRuleIndex(self):
            return MapFilterParser.RULE_filterExpr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFilterExpr" ):
                listener.enterFilterExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFilterExpr" ):
                listener.exitFilterExpr(self)




    def filterExpr(self):

        localctx = MapFilterParser.FilterExprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_filterExpr)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 34
            self.match(MapFilterParser.T__4)
            self.state = 35
            self.match(MapFilterParser.T__1)
            self.state = 36
            self.function_name()
            self.state = 37
            self.match(MapFilterParser.T__2)
            self.state = 38
            self.iterable_name()
            self.state = 39
            self.match(MapFilterParser.T__3)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Function_nameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(MapFilterParser.ID, 0)

        def getRuleIndex(self):
            return MapFilterParser.RULE_function_name

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFunction_name" ):
                listener.enterFunction_name(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFunction_name" ):
                listener.exitFunction_name(self)




    def function_name(self):

        localctx = MapFilterParser.Function_nameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_function_name)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 41
            self.match(MapFilterParser.ID)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Iterable_nameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(MapFilterParser.ID, 0)

        def getRuleIndex(self):
            return MapFilterParser.RULE_iterable_name

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIterable_name" ):
                listener.enterIterable_name(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIterable_name" ):
                listener.exitIterable_name(self)




    def iterable_name(self):

        localctx = MapFilterParser.Iterable_nameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_iterable_name)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 43
            self.match(MapFilterParser.ID)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx






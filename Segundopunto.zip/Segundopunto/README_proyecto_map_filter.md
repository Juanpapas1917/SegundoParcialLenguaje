
# Proyecto: Procesamiento de Expresiones con Map y Filter

Este proyecto implementa un parser y un lexer para procesar expresiones utilizando las funciones `MAP` y `FILTER` a través de gramáticas definidas con ANTLR. El lenguaje objetivo es Python, y el programa permite leer expresiones de un archivo de texto y procesarlas.

## Requisitos Previos

1. **Python 3.12.3**
2. **ANTLR 4.13.1**
3. Instalación de los paquetes especificados en `requirements.txt`.

## Estructura del Proyecto

- **MapFilter.g4**: Archivo que contiene la gramática para las funciones `MAP` y `FILTER`.
- **MapFilterLexer.py**: Lexer generado por ANTLR.
- **MapFilterParser.py**: Parser generado por ANTLR.
- **main.py**: Script principal que ejecuta el procesamiento de expresiones desde el archivo `input.txt`.
- **input.txt**: Archivo de entrada con las expresiones a procesar.

## Instrucciones de Uso

1. **Generar el Lexer y Parser con ANTLR**:
   Ejecuta el siguiente comando para generar los archivos necesarios a partir de la gramática:

   ```bash
   antlr4 -Dlanguage=Python3 MapFilter.g4
   ```

2. **Ejecutar el Programa**:
   Usa el siguiente comando para ejecutar el archivo `main.py`, que lee y procesa las expresiones del archivo `input.txt`:

   ```bash
   python3 main.py input.txt
   ```

## Entorno Virtual

Este proyecto incluye un entorno virtual (`venv`) con todas las dependencias necesarias. Para activarlo:

- En Linux/macOS:
  
  ```bash
  source venv/bin/activate
  ```

- En Windows:

  ```bash
  .env\Scriptsctivate
  ```

## Autor

Proyecto desarrollado por [Tu Nombre].

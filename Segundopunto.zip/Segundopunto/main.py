import sys
from antlr4 import *
from MapFilterLexer import MapFilterLexer
from MapFilterParser import MapFilterParser
from MapFilterListener import ParseTreeListener

# Definir las funciones y los iterables
def square(x):
    return x * x

def is_even(x):
    return x % 2 == 0

functions = {
    'square': square,
    'is_even': is_even,
}

iterables = {
    'numbers': [1, 2, 3, 4, 5],
}

class MapFilterExecutor(ParseTreeListener):
    def __init__(self, functions, iterables):
        self.functions = functions
        self.iterables = iterables

    def exitMapExpr(self, ctx):
        func_name = ctx.function_name().getText()
        iterable_name = ctx.iterable_name().getText()
        func = self.functions.get(func_name)
        iterable = self.iterables.get(iterable_name)
        if func and iterable:
            result = list(map(func, iterable))
            print('Resultado de MAP:', result)
        else:
            print('Error: función o iterable no encontrado')

    def exitFilterExpr(self, ctx):
        func_name = ctx.function_name().getText()
        iterable_name = ctx.iterable_name().getText()
        func = self.functions.get(func_name)
        iterable = self.iterables.get(iterable_name)
        if func and iterable:
            result = list(filter(func, iterable))
            print('Resultado de FILTER:', result)
        else:
            print('Error: función o iterable no encontrado')

def main():
    # Leer la entrada desde un archivo o entrada estándar
    if len(sys.argv) > 1:
        input_stream = FileStream(sys.argv[1], encoding='utf-8')
    else:
        input_stream = InputStream(sys.stdin.read())

    lexer = MapFilterLexer(input_stream)
    stream = CommonTokenStream(lexer)
    parser = MapFilterParser(stream)
    tree = parser.program()

    executor = MapFilterExecutor(functions, iterables)
    walker = ParseTreeWalker()
    walker.walk(executor, tree)

if __name__ == '__main__':
    main()

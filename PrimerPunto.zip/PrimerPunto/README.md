
## Instrucciones para la ejecución

Para resolver el primer ejercicio que involucra operaciones con números complejos, asegúrate de seguir estos pasos. Es importante que los requisitos del archivo `requierements.txt` ya hayan sido instalados previamente.

1. Genera los archivos necesarios a partir de la gramática utilizando ANTLR:

   ```bash
   antlr4 -visitor -Dlanguage=Python3 LabeledExpr.g4
   ```

2. Luego, ejecuta el programa con el siguiente comando, proporcionando como argumento el archivo de entrada:

   ```bash
   python3 calc.py input.txt
   ```
